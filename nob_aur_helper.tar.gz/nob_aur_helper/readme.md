# Welcome to a simple AUR helper written in python named nob 
 # 1 - Downloading 🛜.
  - To download nob you need to clone the repo ->
  `git clone ....`
 # 2 - Installing ⬇️.
    ## 2.1 - Checking dependencies for `makepkg -si`
     - Run `pacman -S base-devel fakeroot debugedit
  - Run `makepkg -si` in the folder you had download.
 # 3 Use it
  - You can now use it by doing `nob -h`
